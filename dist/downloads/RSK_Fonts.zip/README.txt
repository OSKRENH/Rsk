Golos Text
TTF: variable font for installation.
WOFF2: web font styles.
License: SIL Open Font License 1.1, see OFL.txt.
