Golos Text
TTF: variable font from Google Fonts for installation.
WOFF2: four web font styles from rsk-development.ru.
License: SIL Open Font License 1.1, see OFL.txt.
Sources: https://github.com/google/fonts/tree/main/ofl/golostext and https://rsk-development.ru